#include <stdio.h>
#include <stdlib.h>
int main()
{
    int i,a;
    float tvendas[10],soma[10],total[10];
    float comissao[10], vcomissao[10];
    char nome [10][30];
    float maiorvalor=0,menorvalor=0;

    for (i=0;i<=9;i++){
       printf("Digite o nome do %d vendedor:\n", i+1);
       gets(nome);
       printf("Digite a Comissao do vendedor:\n");
       scanf("%f",&comissao[i]);
       printf("Digite o TOTAL de vendas do vendedor:\n");
       scanf("%f",&tvendas[i]);
       fflush(stdin);

       vcomissao[i] = (comissao[i] * tvendas[i]) / 100;

       total[i] = vcomissao[i] + tvendas[i];

       if(maiorvalor > total[i] ){

        maiorvalor = total[i];

        printf(" O maior Valor a receber � %f",maiorvalor);

       }
       if(menorvalor < total[i] ){

        menorvalor = total[i];

       }

    }
    //parte 1
    printf("Mostrando Nome e valor referente a comissao");
    for (i=0;i<=9;i++){
    printf("-------------------------------------------\n");
    printf("Nome do %d vendedor: %c\n", i+1,nome[i]);
    printf("Valor na comissao do %d vendedor: %f\n", i+1,vcomissao[i]);
    printf("-------------------------------------------\n");
    }
    //parte 2
    printf("Mostrando Total de vendas de cada vededor");
    for (i=0;i<=9;i++){
    printf("-------------------------------------------\n");
    printf("Valor Total do %d vendedor: %f\n", i+1,tvendas[i]);
    printf("-------------------------------------------\n");
    }
    //parte 3

    return 0;
}
